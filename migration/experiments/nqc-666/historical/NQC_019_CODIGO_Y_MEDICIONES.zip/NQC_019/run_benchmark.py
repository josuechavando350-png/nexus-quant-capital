"""Preregistered CPU measurements. No trading. All samples retained, no filtering."""
from __future__ import annotations
import array, hashlib, json, math, os, platform, random, subprocess, sys
from pathlib import Path
from reference import candidate, encode, mutants, oracle
ROOT=Path(__file__).resolve().parent

def stats(ns):
 s=sorted(ns);n=len(s)
 def q(p):return s[math.ceil(n*p)-1]
 return dict(n=n,p50_ns=q(.5),p95_ns=q(.95),p99_ns=q(.99),max_ns=s[-1],min_ns=s[0],
             above_3000_ns=sum(x>3000 for x in s),p99_target_met=q(.99)<=3000)

def read_samples(path):
 a=array.array('Q');a.frombytes(path.read_bytes());assert a.itemsize==8
 return a

def main():
 profiles={}
 for n in (4,16):profiles[f'warm_{n}']=[candidate(n,i+19) for i in range(256)]
 mixed=[]
 for i in range(64):
  all_cases=list(mutants(candidate(16,i+900)))
  mixed.extend([all_cases[0][1],all_cases[(i% (len(all_cases)-1))+1][1]])
 profiles['mixed_16']=mixed;profiles['flushed_16']=profiles['warm_16']
 for label,rows in profiles.items():
  raw=('\n'.join(map(encode,rows))+'\n').encode();(ROOT/'inputs'/f'{label}.txt').write_bytes(raw)
  if label!='mixed_16':assert all(oracle(c)[0]==0 for c in rows)
 out=ROOT/'evidence/bench';out.mkdir(exist_ok=True)
 manifest={'plan_sha256':hashlib.sha256((ROOT/'EXPERIMENT_PLAN.md').read_bytes()).hexdigest(),
 'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
 'compiler_flags':'-std=c++17 -O3 -Wall -Wextra -Werror -fno-lto; separately compiled screen.o',
 'platform':platform.platform(),'python':sys.version,'byteorder':sys.byteorder,
 'cpu':subprocess.check_output(['lscpu'],text=True),'clock':'CLOCK_MONOTONIC_RAW',
 'percentiles':'nearest rank, individual calls, no overhead subtraction, no outlier removal',
 'sources_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src').glob('*')},
 'binary_sha256':hashlib.sha256((ROOT/'build/bench').read_bytes()).hexdigest(),
 'scope':'only predecoded in-memory screen; not discovery, proof verification, RPC, EVM, signing, serialization, transport or inclusion',
 'commercial_admission':False,'runs':[]}
 rng=random.Random(190019)
 for rep in range(5):
  order=list(profiles);rng.shuffle(order)
  for label in order:
   count=20000 if label=='flushed_16' else 200000
   prefix=out/f'{label}_{rep}'
   cmd=[str(ROOT/'build/bench'),str(ROOT/'inputs'/f'{label}.txt'),str(count),str(190000+rep),str(int(label=='flushed_16')),str(prefix)]
   p=subprocess.run(cmd,capture_output=True,text=True,timeout=30,check=True)
   info=json.loads(p.stdout);summary=stats(read_samples(prefix.with_suffix('.bin')))
   control=stats(read_samples(out/(prefix.name+'_clock.bin')))
   r=dict(profile=label,repetition=rep,metadata=info,stats=summary,clock_control=control,
    samples_sha256=hashlib.sha256(prefix.with_suffix('.bin').read_bytes()).hexdigest(),
    corpus_sha256=hashlib.sha256((ROOT/'inputs'/f'{label}.txt').read_bytes()).hexdigest())
   manifest['runs'].append(r)
   print(label,rep,summary,flush=True)
   (ROOT/'evidence/benchmark.json').write_text(json.dumps(manifest,indent=2)+'\n')
 manifest['profile_results']={label:{
  'all_five_p99_at_most_3000ns':all(r['stats']['p99_target_met'] for r in manifest['runs'] if r['profile']==label),
  'p50_range_ns':[min(r['stats']['p50_ns'] for r in manifest['runs'] if r['profile']==label),max(r['stats']['p50_ns'] for r in manifest['runs'] if r['profile']==label)],
  'p99_range_ns':[min(r['stats']['p99_ns'] for r in manifest['runs'] if r['profile']==label),max(r['stats']['p99_ns'] for r in manifest['runs'] if r['profile']==label)],
  'max_ns':max(r['stats']['max_ns'] for r in manifest['runs'] if r['profile']==label),
  'samples':sum(r['stats']['n'] for r in manifest['runs'] if r['profile']==label),
  'above_3000_ns':sum(r['stats']['above_3000_ns'] for r in manifest['runs'] if r['profile']==label)
  } for label in profiles}
 (ROOT/'evidence/benchmark.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(manifest['profile_results'],indent=2))
if __name__=='__main__':main()
