# NQC019 - precontrol financiero local de baja latencia

Estado: OFFLINE_PRECHECK_MEASURED_NOT_INTEGRATED_NOT_COMMERCIAL.

Es una pieza NUEVA e independiente, no el motor completo NQC ni una aceleración
comparada con el benchmark recordado de 11 microsegundos. No se localizó el
artefacto original de 11 us en la búsqueda acotada. No se declara refutado.

## Qué se hizo

Se implementó un precontrol C++ con arrays acotados (1..16 instrucciones) y
aritmética entera comprobada. Examina reservas de gas por paso, fondos previamente
declarados, devolución, sobrantes, caja del financiador, pago del proponente,
WETH del operador, coherencia de bloque/hash/índice, caducidad y evidencia faltante.
No realiza selección de mercados, cotizaciones, liquidaciones, prueba criptográfica,
concurrencia, RPC, firmas, serialización ni envíos.

La entrada ya está tipada y presupone resultados de una simulación/validación
anterior. El tiempo de producir/verificar esa entrada NO se mide. Los flags de
evidencia no crean una prueba: un futuro adaptador tendría que comprobarla y
vincularla al candidato. Ese adaptador NO está implementado. El núcleo no está
integrado con el sistema existente; no sustituye los controles de NQC018.

## Semántica estricta

- Los campos financieros son uint128 explícitos; el lector rechaza datos fuera
  de dominio, incluidos uint256 demasiado grandes. Nunca trunca ni usa flotantes.
- ETH y WETH siguen separados. Cada value_to_sponsor es una transferencia al
  financiador. native_credit_after es un ingreso nativo declarado después de
  ese paso: necesita justificación externa, como el resto de entradas.
- Una instrucción necesita gas_limit * max_fee + value ANTES de ejecutarse.
  El saldo posterior descuenta gas_used * effective_price + value. Son conceptos
  distintos; conocer un coste esperado no elimina la reserva máxima.
- Todos los topups deben estar fijados/conocidos; no se infiere el algoritmo de
  Titan o Quasar ni se solicita financiación. La suma respeta funding_cap.
- La reserva conservadora del sponsor cubre todos los anticipos, la reserva de
  overhead y el pago del proponente. No es un cálculo de reserva mínima; no
  aprovecha ingresos intermedios hipotéticos para relajar esa condición.
- sponsor_other_inflows excluye las devoluciones ya sumadas. overhead_cost incluye
  gas de fondeo/pago propio, NO el gas del operador: este ya reduce su devolución.
  other_costs son otros costes nativos declarados pagaderos dentro del balance
  de cierre; condiciones o pasivos adicionales requieren validación fuera del núcleo.
- sponsor_margin es una cota de caja bajo entradas declaradas, no P&L real auditado.
- Los cuatro estados deben coincidir en altura, hash e índice. Esto no verifica
  pruebas Merkle, almacenamiento, tx0, DEX, precios ni autenticidad del estado.
- epoch/current_epoch son valores comparados, NO una implementación de seqlock o
  sincronización. El adaptador futuro debe impedir TOCTOU y revalidar antes de enviar.
- Los timestamps internos deben compartir reloj monotónico. El corte de proveedor
  necesita observación y conversión con incertidumbre externa; NO se obtiene de
  restar la hora pública de un bloque. El presupuesto de envío debe caber ESTRICTAMENTE
  antes de corte y caducidad de la financiación.
- Aun con reasons=0, commercial_admission es siempre FALSE. No hay método de envío.

Bits de evidencia requeridos (todos ficticios en los casos positivos de laboratorio):
1 estado y ejecución auténticos verificados; 2 disponibilidad/reserva del financiador;
4 ausencia de recurso y asignación de pérdidas; 8 obligaciones/costes completos;
16 corte temporal observado; 32 declaración de financiación válida antes del candidato.
Cada bit corresponde a un hecho que aún se debe documentar para NQC real.

## Resultados y procedencia

Ver RESULTADOS.json, evidence/checks.json, evidence/benchmark.json y el informe PDF.
Se guardan las 3,100,000 muestras de tiempo en uint64 nativo little-endian .bin,
además de controles de reloj. No son liquidaciones ni muestras de oportunidades.
Se conservaron los picos; no existe garantía de máximo 3 us.

Se cotejaron los 12 resúmenes de NQC018, SIN inventar prefijos ni reconstruir los
68 recibos. Ningún caso NQC018 obtiene aprobación comercial. El ZIP original de
NQC018 se validó contra 20 hashes; no se modificó. El nuevo código no se publicó
ni ejecutó en GitHub Actions. main se consultó en 16e352225ba8a6a931834c4edf3d86d9a2924b7d;
la base documental consultada fue 71d276e2c7f67b3f564d086463efca09cfbbf940.

## Reproducir sin red ni instalación

Requisitos: Linux x86_64, g++ con soporte unsigned __int128 y Python 3 estándar.
El benchmark usa CLFLUSH en la memoria de su propio proceso; no desactiva protecciones
ni modifica ajustes del sistema. Se fija únicamente a una CPU ya permitida.

Trabajar en una COPIA para no sobrescribir la evidencia entregada:

    make all
    make test
    make sanitize
    make benchmark
    python3 verify_results.py

make benchmark ejecuta otra medición, por lo que sus cifras no tienen que coincidir
con las originales. Cambiar CPU, carga, compilador, tamaño del registro o integración
invalida trasladar las cifras sin una nueva medición.

## Límites y decisión

No hubo ejecución EVM nueva, firma, cartera, transacción pública, gasto, contacto
comercial ni cambios remotos. Las advertencias de indentación de dos compilaciones
de desarrollo se corrigieron sin quitar -Werror; las pruebas finales no mostraron
discrepancias. El sanitizador repite las MISMAS pruebas, no crea más casos únicos.
No se ejecutó el verificador global de aislamiento ni las suites Rust/Solidity:
no se propone integrar/modificar sus componentes. Este expediente es local aislado.

La siguiente prioridad comercial permanece obtener una declaración o límite de
financiación aplicable al candidato ANTES de fijarlo; las páginas públicas de envío
consultadas no documentan esa cotización previa. No confundir esa observación
acotada con que el proveedor no pueda ofrecer otra vía. Mantener dinero y envío bloqueados.
