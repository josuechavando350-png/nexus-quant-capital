"""Verify hashes and recalculate every reported per-call percentile offline."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
from run_benchmark import read_samples,stats
ROOT=Path(__file__).resolve().parent
b=json.loads((ROOT/'evidence/benchmark.json').read_text())
for r in b['runs']:
 p=ROOT/'evidence/bench'/f"{r['profile']}_{r['repetition']}.bin"
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['samples_sha256']
 assert stats(read_samples(p))==r['stats']
 assert stats(read_samples(p.with_name(p.stem+'_clock.bin')))==r['clock_control']
assert sum(r['stats']['n'] for r in b['runs'])==3100000
for n,h in b['sources_sha256'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h
manifest=ROOT/'MANIFEST.sha256'
if manifest.exists():
 for line in manifest.read_text().splitlines():
  h,n=line.split(None,1);p=ROOT/n.strip()
  assert '..' not in Path(n.strip()).parts and not Path(n.strip()).is_absolute()
  assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
print('PASS: all 20 timing runs, 3,100,000 samples, source hashes and available manifest')
