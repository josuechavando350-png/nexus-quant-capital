# Búsqueda acotada de los 11 microsegundos

Se consultó la memoria específica del proyecto y se buscó en Library:
- NQC evidencia original benchmark latencia "11 microsegundos"
- NQC "11.3288" "latency"
- NEXUS QUANT CAPITAL "11µs" "11us" benchmark

El relevo maestro de 17 octubre de 2026, sección 11/página 14, clasifica la fuente
original como NO LOCALIZADA, NO REFUTADA. Distingue 11.3288x de Multicall3 (factor)
y cifras de transporte medidas en milisegundos/segundos. Las directivas de Astra
repiten que se exija CPU, compilador, tramo, muestras y percentiles. No se encontró
un nuevo artefacto primario del supuesto benchmark en esos resultados.

Una búsqueda de código "microseconds" en la rama predeterminada de
josuechavando350-png/nexus-quant-capital devolvió cero resultados. No se inspeccionó
exhaustivamente todo el historial, todos los artefactos ni otro repositorio.
Por tanto, NQC019 NO afirma que el usuario recuerde mal, ni que se refutó la cifra.

NQC019 mide un precontrol NUEVO de fichas previamente construidas, no el tramo
desconocido de la cifra antigua. No es válido calcular 11/NQC019 como aceleración
obtenida ni decir que el bot completo bajó de 11 a 3 microsegundos.

Referencia metodológica consultada: https://google.github.io/benchmark/user_guide.html
Se tomaron precauciones de consumo observable de resultados y repetición; se usa
un arnés propio sin dependencia de Google Benchmark y sin atribuirle validación.
Regla de reserva y gas: https://eips.ethereum.org/EIPS/eip-1559
