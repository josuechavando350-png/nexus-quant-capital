# NQC019 - revisión independiente y siguiente puerta

## Mandato y estado

Trabaja exclusivamente sobre NQC y el expediente adjunto. No gastes, firmes,
contactes builders, uses carteras o envíes transacciones públicas. No modifiques
main, ramas anteriores, originales ni otro repositorio. Conserva AGENTS.md.
NQC019 es LOCAL, NOT_PUBLISHED, no integrado, sin nuevos workflows ni pruebas EVM.
No repitas las suites 015/018 por defecto para aumentar un contador.

Base documental leída: 71d276e2c7f67b3f564d086463efca09cfbbf940.
Código EVM018 previo: bfe251bd7f9b8ef768fc9ce99f42ed0ded3f73db.
Main consultado: 16e352225ba8a6a931834c4edf3d86d9a2924b7d.
Run018 previo: 39094293890; job117577385192. Esta etapa no lo reejecutó.

El usuario recuerda 11 microsegundos y fija un objetivo de 3. El documento maestro
recuperado sigue clasificando 11 us como NO LOCALIZADO, NO REFUTADO. El factor
11.3288x no es una latencia. No afirmes que NQC019 aceleró ese tramo desconocido.

## Evidencia nueva que auditar

Núcleo C++ independiente de 1..16 instrucciones: src/screen.hpp y src/screen.cpp.
Controles de lectura estricta: src/io.hpp. Especificación independiente Python
por sumas de prefijos: reference.py. Generación y contraste: tests/run_checks.py.
No hay llamadas a RPC, envío, búsqueda de oportunidades ni firmas en ese código.

Se ejecutaron 55 controles explícitos, 12 rechazos de entrada mal formada y
20,000 casos diferenciales aleatorios con semilla fija, sin discrepancias. Son
67 controles más el corpus, no transacciones. La compilación con ASAN/UBSAN
repitió las MISMAS pruebas; no la sumes como otros 20,000 casos únicos. También
se reconstruyó desde copia limpia, con iguales binarios y resultados.

Las 3,100,000 mediciones son llamadas individuales a un precontrol de fichas
precargadas. Cinco repeticiones por carga; sin quitar picos ni restar coste del
reloj. Se incluyen todas las muestras, los corpus y los SHA-256 en el ZIP.
Peor p99 de cinco repeticiones: cuatro pasos calientes119ns; dieciséis250ns;
mezcla válida/inválida260ns; entrada con líneas de caché expulsadas1096ns.
Se observaron1457 muestras sobre3000ns; el máximo fue1653341ns. Por tanto NO
existe garantía de máximo3us ni latencia de producción demostrada.

No se usa Google Benchmark; sólo se consultaron sus recomendaciones metodológicas.
Compilador g++14.2.0, -O3, C++17, sinLTO, función compilada en otra unidad y resultado
consumido. CPU reportada por contenedor: Intel Xeon Platinum8573C, hipervisorKVM.
CLOCK_MONOTONIC_RAW; proceso fijado sólo a una CPU permitida. No configuración
privilegiada, instalación o servicio contratado.

## Revisiones que sí importan

1. Verifica MANIFEST.sha256 y ejecuta verify_results.py sin alterar los originales.
   Después trabaja en copia limpia y ejecuta make test y make sanitize. Audita
   el oracle por prefijos: no asumas independencia sólo porque es otro lenguaje.
2. Comprueba que el compilador no eliminó el cálculo: fuentes, objeto, símbolos,
   desensamblado, llamada externa sinLTO, corpus variable y checksum consumido.
   Recalcula cada p50/p95/p99 desde su .bin little-endian de uint64. Publica los
   máximos y rechazos aunque contradigan el objetivo. No mezcles tiempos de un
   lote dividido entre N con percentiles de llamadas; aquí son individuales.
3. Busca contraejemplos dentro del dominio uint128 declarado: reserva máxima
   distinta de coste real, overflow, nuevos fondos tras congelar instrucciones,
   devolución omitida, sobrante, pérdidas del sponsor, proponente no pagado,
   bloque/hash/índice mezclado y cotización que vence durante el presupuesto de envío.
4. El núcleo NO autentica Merkle/estado, cotizaciones, firmas ni condiciones. Sus
   evidence_mask son aserciones de un adaptador futuro; ponerlos en63 no demuestra
   financiación. epoch es una comparación, no un seqlock. Exige un contexto
   inmutable ligado a plan_hash, bloques/índice, origen de datos, cotización y
   condiciones, e invalidación al cambiar el estado. No permitas TOCTOU.
5. Los12 resultados018 se cotejaron sólo como resúmenes. No se fabricaron prefijos
   ni se descargó su exportación completa. No afirmar lectura de68 recibos.
6. La prioridad comercial sigue siendo una declaración previa o mecanismo de
   liquidación acotada realmente aplicable a Titan/Quasar. Las páginas de envío
   revisadas reciben txs firmadas; no se encontró allí un anticipo preacordado
   para DECLARED_REQUOTE. Esto NO demuestra inexistencia de otra vía. Establece
   qué entrada falta sin inventar campos/API/condiciones o recurrir a gastos/contacto.

## Decisión y límites de integración

Mantener el precontrol como prototipo aislado. Su máximo beneficio actual es
filtrar pronto fichas incoherentes o no financiables; no certifica una operación.
commercial_admission permanece false en TODA salida. Sin adaptador verificado,
estado auténtico completo, financiación sin recurso y evidencia temporal, no
cambia la evaluación comercial ni se proyectan ingresos.

El cuello de botella comercial no se resuelve añadiendo más microbenchmarks.
Cualquier prueba siguiente debe cerrar una entrada concreta o comprobar la
integración sobre evidencia real. No llames ataque a interferir con terceros:
la tarea es selección competitiva y controles de NQC, no explotar sistemas ajenos.

## Entrega

Devuelve dictamen, contraejemplos, scripts y evidencia diferenciando nuevo,
repetido, no ejecutado y bloqueado. Entrega archivos realmente creados en el
contenedor mediante enlaces sandbox, no referencias inventadas de Library.
PDF: comprobar apertura, texto y render de cada página. ZIP: verificar todos
los hashes y conservar las muestras crudas. No afirmar descarga universal.
