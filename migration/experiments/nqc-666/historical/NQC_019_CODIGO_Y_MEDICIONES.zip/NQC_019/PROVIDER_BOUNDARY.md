# NQC019 - frontera documental de financiación

Revisión de fuentes primarias durante esta etapa, sólo páginas públicas; no se
invocaron RPC de builders, no se enviaron candidatos y no hubo contacto comercial.

## Titan

La página de eth_sendBundle describe gas y value condicionados a recuperar el
coste mediante el incremento del balance del builder. El esquema visible recibe
transacciones ya firmadas y el ejemplo de respuesta devuelve bundleHash. En ESA
página no se documenta un importe de anticipo acordado antes de firmar, ni un campo
que lo fije. Eso deja sin justificar trasladar DECLARED_REQUOTE de NQC018 a ese
API exacto; NO demuestra que no exista otro acuerdo/interfaz.
Fuente: https://docs.titanbuilder.xyz/api/eth_sendbundle

Su artículo técnico de 2023 describe simulación, transferencia antepuesta y posterior
consideración como candidato. Es descripción del mecanismo, no aceptación de NQC.
Fuente: https://titanbuilder.substack.com/p/titan-tech-teatime-1

Las estadísticas distinguen recibir, simular, incluir en un bloque candidato y
someterlo a relay. Submitted no prueba que ese bloque ganara. Por tanto no puede
usarse como comprobante de beneficio ni de inclusión final.
Fuente: https://docs.titanbuilder.xyz/bundle-tracing

## Quasar

El esquema visible también recibe transacciones firmadas y devuelve bundleHash.
La sección de patrocinio describe gas condicionado al aumento del saldo del builder;
no se amplía por inferencia a value. En esa página tampoco se identificó una
cotización de anticipo previa. No hay rechazo observado de NQC.
Fuente: https://docs.quasar.win/api/eth_sendbundle

## Lo que NO se resolvió

Oferta aplicable, importe o rango realmente comprometido, reserva utilizable,
receptor económico autorizado y asignación de pérdidas sin deuda personal.
Las búsquedas de los índices llms.txt y una página eth_callbundle no devolvieron
contenido mediante la herramienta: no se usaron para afirmar ausencia de funciones.
El alcance documental se limita a las páginas disponibles, no a todos los acuerdos
privados ni a una inspección del algoritmo interno de ningún proveedor.

## Puerta ejecutable

NQC019 trata la ausencia de esa evidencia como bloqueo, incluso cuando la cuenta
sintética es positiva. Un flag en el test NO demuestra que la prueba exista.
Para integrar, el adaptador lento debe validar procedencia/alcance/vigencia, enlazar
plan_hash, bloque/hash/índice, importes, direcciones y condiciones; sólo luego puede
crear una ficha inmutable para el precontrol rápido. Debe revalidar generación y
corte antes de cualquier acción. Ese adaptador sigue pendiente y no se autorizan
acciones financieras mediante este expediente.
