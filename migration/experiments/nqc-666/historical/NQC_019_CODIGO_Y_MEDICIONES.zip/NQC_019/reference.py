"""Independent big-integer prefix-sum specification; OFFLINE, not a sender.

The C++ reducer is incremental. This oracle derives the pre-step balance from
cumulative credits and debits, enforcing the same bounded external domain.
"""
from __future__ import annotations
import copy, random
U=(1<<128)-1
HEADER='chain_id epoch current_epoch block_number'.split()
TIMES='now_ns received_ns max_age_ns cutoff_ns quote_expiry_ns send_budget_ns evidence_mask funding_known package_complete'.split()
MONEY='operator_initial funding_cap sponsor_reserve overhead_reserve overhead_cost sponsor_other_inflows proposer_required proposer_paid other_costs min_sponsor_margin operator_weth_new min_operator_weth'.split()
STEPS='gas_limit max_fee gas_used effective_price funding_before value_to_sponsor native_credit_after'.split()
REASONS={1:'INVALID',2:'EVIDENCE_MISSING',4:'STATE_MISMATCH',8:'TIME_INVALID',16:'FUNDING_UNKNOWN',32:'PREFIX_INSUFFICIENT',64:'OVERFLOW',128:'FUNDING_CAP',256:'RESIDUAL_FINANCING',512:'PROPOSER_UNPAID',1024:'SPONSOR_MARGIN',2048:'OPERATOR_MARGIN',4096:'PERSONAL_CAPITAL',8192:'PACKAGE_INCOMPLETE',16384:'SPONSOR_RESERVE',32768:'GENERATION_CHANGED'}

def candidate(n=4,seed=0):
    rng=random.Random(seed)
    steps=[]
    for i in range(n):
        gas=21000+rng.randrange(200000)
        steps.append(dict(zip(STEPS,[gas,3*10**9,gas-1000,2*10**9,0,0,0])))
    funding=3*10**17
    totalcost=sum(x['gas_used']*x['effective_price'] for x in steps)
    # Funding meets both final value and MAX gas fee reservation, with no guessed
    # leftover: last transaction deliberately uses effective==maximum fee.
    steps[-1]['max_fee']=steps[-1]['effective_price']
    steps[-1]['gas_used']=steps[-1]['gas_limit']
    totalcost=sum(x['gas_used']*x['effective_price'] for x in steps)
    steps[0]['funding_before']=funding
    steps[-1]['value_to_sponsor']=funding-totalcost
    c=dict(chain_id=1,epoch=1,current_epoch=1,block_number=500,
      state_numbers=[500]*4,state_index=1,state_indices=[1]*4,
      state_hashes=['ab'*32]*4, now_ns=200000,received_ns=100000,
      max_age_ns=1000000,cutoff_ns=10000000,quote_expiry_ns=10000000,
      send_budget_ns=500000,evidence_mask=63,funding_known=1,package_complete=1,
      operator_initial=0,funding_cap=funding,sponsor_reserve=10**18,
      overhead_reserve=200000000000000,overhead_cost=84000000000000,
      sponsor_other_inflows=100000000000000000,proposer_required=40000000000000000,
      proposer_paid=40000000000000000,other_costs=1000000000000,
      min_sponsor_margin=1,operator_weth_new=159365645570551238,min_operator_weth=1,
      steps=steps)
    return c

def encode(c):
    vals=[c[k] for k in HEADER]+c['state_numbers']+[c['state_index']]+c['state_indices']+c['state_hashes']
    vals += [c[k] for k in TIMES]+[len(c['steps'])]+[c[k] for k in MONEY]
    for s in c['steps']:vals += [s[k] for k in STEPS]
    return ' '.join(map(str,vals))

def oracle(c):
    n=len(c['steps']); mask=0
    if not 1<=n<=16 or c['funding_known'] not in (0,1) or c['package_complete'] not in (0,1) or not 0<=c['evidence_mask']<=63 or c['overhead_cost']>c['overhead_reserve']:
        return (1,None)
    if c['evidence_mask']!=63:mask|=2
    if not c['funding_known']:mask|=16
    if not c['package_complete']:mask|=8192
    if c['operator_initial']:mask|=4096
    if not c['epoch'] or c['epoch']!=c['current_epoch']:mask|=32768
    if c['chain_id']!=1 or not c['block_number'] or c['state_hashes'][0]=='00'*32 or any(c['state_numbers'][i]!=c['block_number'] or c['state_indices'][i]!=c['state_index'] or c['state_hashes'][i]!=c['state_hashes'][0] for i in range(4)):mask|=4
    remaining=min(c['cutoff_ns'],c['quote_expiry_ns'])-c['now_ns']
    if not c['received_ns'] or not c['max_age_ns'] or not c['send_budget_ns'] or c['now_ns']<c['received_ns'] or c['now_ns']-c['received_ns']>c['max_age_ns'] or c['send_budget_ns']>=remaining:mask|=8
    costs=[]; topups=[]; values=[]; credits=[]
    for s in c['steps']:
        if s['gas_limit']==0 or s['gas_used']>s['gas_limit'] or s['effective_price']>s['max_fee']:
            return (mask|1,None)
        needed=s['gas_limit']*s['max_fee']+s['value_to_sponsor']
        topups.append(s['funding_before'])
        before=c['operator_initial']+sum(topups)+sum(credits)-sum(costs)-sum(values)
        if max(needed,before,sum(topups))>U:return(mask|64,None)
        if before<needed:return(mask|32,None)
        costs.append(s['gas_used']*s['effective_price']);values.append(s['value_to_sponsor']);credits.append(s['native_credit_after'])
        after=c['operator_initial']+sum(topups)+sum(credits)-sum(costs)-sum(values)
        if max(after,sum(costs),sum(values))>U:return(mask|64,None)
    residual=after; funding=sum(topups); refund=sum(values)
    if funding>c['funding_cap']:mask|=128
    if residual:mask|=256
    reserve=funding+c['overhead_reserve']+c['proposer_paid']
    income=c['sponsor_other_inflows']+refund
    expense=funding+c['overhead_cost']+c['proposer_paid']+c['other_costs']
    if max(reserve,income,expense)>U:return(mask|64,None)
    if reserve>c['sponsor_reserve']:mask|=16384
    if c['proposer_paid']<c['proposer_required']:mask|=512
    margin=max(0,income-expense)
    if income<=expense or margin<c['min_sponsor_margin']:mask|=1024
    if not c['operator_weth_new'] or c['operator_weth_new']<c['min_operator_weth']:mask|=2048
    return mask,(funding,sum(costs),refund,residual,margin)

def mutants(c):
    def m(name,fn):
        x=copy.deepcopy(c);fn(x);return name,x
    yield 'valid',copy.deepcopy(c)
    for i in range(6):yield m(f'unknown_evidence_{i}',lambda x,i=i:x.update(evidence_mask=63^(1<<i)))
    yield m('unknown_advance',lambda x:x.update(funding_known=0))
    yield m('other_chain',lambda x:x.update(chain_id=2))
    yield m('mixed_block',lambda x:x['state_numbers'].__setitem__(2,501))
    yield m('reorg_same_height',lambda x:x['state_hashes'].__setitem__(1,'ba'*32))
    yield m('wrong_transaction_index',lambda x:x['state_indices'].__setitem__(1,2))
    yield m('zero_hash',lambda x:x.update(state_hashes=['00'*32]*4))
    yield m('epoch_changed',lambda x:x.update(current_epoch=2))
    yield m('zero_epoch',lambda x:x.update(epoch=0,current_epoch=0))
    yield m('late_at_cutoff',lambda x:x.update(now_ns=x['cutoff_ns']))
    yield m('deadline_exact_budget',lambda x:x.update(cutoff_ns=x['now_ns']+x['send_budget_ns']))
    yield m('expired_funding',lambda x:x.update(quote_expiry_ns=x['now_ns']))
    yield m('funding_expires_during_send',lambda x:x.update(quote_expiry_ns=x['now_ns']+x['send_budget_ns']-1))
    yield m('stale_input',lambda x:x.update(now_ns=x['received_ns']+x['max_age_ns']+1))
    yield m('clock_reversed',lambda x:x.update(now_ns=x['received_ns']-1))
    yield m('unknown_cutoff',lambda x:x.update(cutoff_ns=0))
    yield m('unknown_age_budget',lambda x:x.update(max_age_ns=0))
    yield m('unknown_send_budget',lambda x:x.update(send_budget_ns=0))
    yield m('capital_not_zero',lambda x:x.update(operator_initial=1))
    yield m('funding_one_wei_short',lambda x:x['steps'][0].update(funding_before=x['steps'][0]['funding_before']-1))
    yield m('funding_extra_is_not_profit',lambda x:x['steps'][0].update(funding_before=x['steps'][0]['funding_before']+1))
    yield m('maxfee_raise',lambda x:x['steps'][-1].update(max_fee=3000000000))
    yield m('payout_missing',lambda x:x.update(proposer_paid=0))
    yield m('payout_short',lambda x:x.update(proposer_paid=x['proposer_required']-1))
    yield m('sponsor_loses_owner_gains',lambda x:x.update(sponsor_other_inflows=0))
    yield m('sponsor_unknown_minimum',lambda x:x.update(min_sponsor_margin=U))
    yield m('owner_zero',lambda x:x.update(operator_weth_new=0))
    yield m('owner_below_minimum',lambda x:x.update(min_operator_weth=x['operator_weth_new']+1))
    yield m('incomplete',lambda x:x.update(package_complete=0))
    yield m('cap_short',lambda x:x.update(funding_cap=1))
    yield m('sponsor_reserve_short',lambda x:x.update(sponsor_reserve=1))
    yield m('sum_overflow',lambda x:x.update(sponsor_other_inflows=U))
    yield m('overhead_reserve_overflow',lambda x:x.update(overhead_reserve=U))
    yield m('balance_overflow',lambda x:x['steps'][0].update(funding_before=U,native_credit_after=U))
    yield m('invalid_gas',lambda x:x['steps'][0].update(gas_used=x['steps'][0]['gas_limit']+1))
    yield m('invalid_fee',lambda x:x['steps'][0].update(effective_price=x['steps'][0]['max_fee']+1))
    yield m('invalid_overhead',lambda x:x.update(overhead_cost=x['overhead_reserve']+1))
    yield m('bad_flag',lambda x:x.update(funding_known=2))
    yield m('bad_evidence_mask',lambda x:x.update(evidence_mask=64))
    yield m('zero_steps',lambda x:x.update(steps=[]))
