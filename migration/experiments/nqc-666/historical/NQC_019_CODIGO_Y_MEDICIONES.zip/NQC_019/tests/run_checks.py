"""Finite tests of NQC019 only. No networking, wallets or contract execution."""
from __future__ import annotations
import argparse, copy, hashlib, json, random, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from reference import candidate, encode, oracle, mutants, REASONS, U

def main():
 p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,default=ROOT/'build/eval');p.add_argument('--output',default='checks.json');a=p.parse_args()
 explicit=list(mutants(candidate()))
 for n in (1,8,16):explicit.append((f'valid_{n}_steps',candidate(n,123)))
 for n in (0,1,2,3):
  c=candidate(4,88);c['steps'][n]['funding_before']+=7;c['steps'][-1]['value_to_sponsor']+=7;c['funding_cap']+=7
  explicit.append((f'funding_prefix_{n}',c))
 # Arithmetic overflow and nonzero intermediate cash, with supported uint64 factors.
 c=candidate();c['steps'][0]['gas_limit']=2**64-1;c['steps'][0]['max_fee']=2**64-1;c['steps'][0]['value_to_sponsor']=2**65
 explicit.append(('reserve_add_overflow',c))
 c=candidate();c['steps'][0]['native_credit_after']=3;c['steps'][-1]['value_to_sponsor']+=3
 explicit.append(('native_credit_not_pretended_funding',c))
 rng=random.Random(190018);corpus=list(explicit)
 for i in range(20000):
  c=candidate(rng.randint(1,16),rng.randrange(1<<32));mode=rng.randrange(20)
  if mode==0:c['steps'][0]['funding_before']-=rng.randint(1,1000)
  elif mode==1:c['steps'][0]['funding_before']+=rng.randint(1,1000)
  elif mode==2:c['evidence_mask']=rng.randrange(63)
  elif mode==3:c['sponsor_other_inflows']=rng.randrange(10**17)
  elif mode==4:c['quote_expiry_ns']=c['now_ns']+rng.randrange(500001)
  elif mode==5:c['current_epoch']=rng.randint(2,1000)
  elif mode==6:c['state_hashes'][rng.randrange(4)]='11'*32
  elif mode==7:c['steps'][-1]['max_fee']+=rng.randrange(1,10**9)
  elif mode==8:c['funding_cap']=rng.randrange(3*10**17)
  elif mode==9:c['sponsor_reserve']=rng.randrange(4*10**17)
  elif mode==10:c['proposer_paid']=rng.randrange(c['proposer_required'])
  elif mode==11:c['operator_weth_new']=rng.randrange(2)
  elif mode==12:c['sponsor_other_inflows']=U-rng.randrange(10**8)
  elif mode==13:c['steps'][rng.randrange(len(c['steps']))]['funding_before']=U-rng.randrange(10**8)
  elif mode==14:c['package_complete']=0
  elif mode==15:c['funding_known']=0
  elif mode==16:c['now_ns']=rng.randrange(2**64)
  elif mode==17:
   v=rng.randrange(10000);c['steps'][0]['native_credit_after']=v;c['steps'][-1]['value_to_sponsor']+=v
  corpus.append((f'random_{i}',c))
 lines=[encode(c) for _,c in corpus]
 raw=('\n'.join(lines)+'\n').encode();(ROOT/'inputs/differential.txt').write_bytes(raw)
 proc=subprocess.run([str(a.binary.resolve())],input=raw,capture_output=True,timeout=30)
 if proc.returncode:raise RuntimeError(proc.stderr.decode())
 rows=proc.stdout.decode().splitlines();assert len(rows)==len(corpus)
 result=[];passes=0
 for (name,c),row in zip(corpus,rows):
  assert row!='PARSE_ERROR',(name,row)
  observed=list(map(int,row.split()));expected,amounts=oracle(c)
  assert observed[0]==expected,(name,expected,observed,c)
  if amounts is not None:assert tuple(observed[1:])==amounts,(name,amounts,observed)
  passes+=expected==0
  if len(result)<len(explicit):
   if name not in ('valid','valid_1_steps','valid_8_steps','valid_16_steps','native_credit_not_pretended_funding') and not name.startswith('funding_prefix_'):
    assert expected!=0,(name,'negative control incorrectly passed')
   result.append({'case':name,'reasons':expected,'labels':[v for k,v in REASONS.items() if k&expected], 'matched':True})
 # Malformed decimal, too-wide uint256, extra/truncated fields and bad hashes.
 valid=encode(candidate());tokens=valid.split();bad=[]
 for value in ('-1','+1','1.0','true',str(2**128),'9'*80):
  t=tokens.copy();t[0]=value;bad.append(' '.join(t))
 t=tokens.copy();t[0]=str(2**64);bad.append(' '.join(t))
 t=tokens.copy();t[13]='gg'*32;bad.append(' '.join(t))
 bad.extend([valid+' 99',' '.join(tokens[:-1]),'', 'x'])
 malformed=subprocess.run([str(a.binary.resolve())],input=('\n'.join(bad)+'\n').encode(),capture_output=True,timeout=15)
 assert malformed.returncode==0,malformed.stderr.decode()
 assert malformed.stdout.decode().splitlines()==['PARSE_ERROR']*len(bad)
 # 018 summary only: no prefix details or receipts are fabricated for the C++ input.
 saved=json.loads((ROOT/'inputs/NQC_018_RESULTADOS.json').read_text())['reported_status']['cases']
 summary=[]
 for r in saved:
  local=(r['package_complete'] and r['residual_financing']==0 and r['builder_cash_after_observed_payout']>0 and r['owner_WETH_new']>0)
  assert local==r['local_economic_gate'];assert r['commercial_admission'] is False
  assert r['personal_liability'] is None and r['commercial_costs'] is None
  summary.append({'case':r['case'],'nqc018_local_gate_matched':local==r['local_economic_gate'],
    'commercial_screen':'BLOCKED_EVIDENCE_MISSING','new_EVM_execution':False})
 output=dict(status='PASS_OFFLINE_ONLY',explicit_controls=len(explicit),parser_rejections=len(bad),
  random_differential_cases=20000,total_comparisons=len(corpus),mismatches=0,
  synthetic_screens_passed=passes,seed=190018,input_sha256=hashlib.sha256(raw).hexdigest(),
  binary_sha256=hashlib.sha256(a.binary.read_bytes()).hexdigest(),explicit_results=result,
  nqc018_summary_only=summary,new_evm_cases=0,commercial_admission=False,
  historical_latency_11_us='NOT_LOCATED_NOT_REFUTED')
 (ROOT/'evidence'/a.output).write_text(json.dumps(output,indent=2)+'\n')
 print(json.dumps({k:v for k,v in output.items() if k not in ('explicit_results','nqc018_summary_only')},indent=2))
if __name__=='__main__':main()
