#pragma once
#include <array>
#include <cstdint>
namespace nqc019 {
using U = unsigned __int128;
constexpr U MAX_U = ~U(0);
constexpr std::uint64_t REQUIRED_EVIDENCE = 63;
constexpr std::size_t MAX_STEPS = 16;
enum Reason : std::uint64_t {
 INVALID=1, EVIDENCE_MISSING=2, STATE_MISMATCH=4, TIME_INVALID=8,
 FUNDING_UNKNOWN=16, PREFIX_INSUFFICIENT=32, OVERFLOW=64, FUNDING_CAP=128,
 RESIDUAL_FINANCING=256, PROPOSER_UNPAID=512, SPONSOR_MARGIN=1024,
 OPERATOR_MARGIN=2048, PERSONAL_CAPITAL=4096, PACKAGE_INCOMPLETE=8192,
 SPONSOR_RESERVE=16384, GENERATION_CHANGED=32768
};
struct Step {
 std::uint64_t gas_limit{}, max_fee{}, gas_used{}, effective_price{};
 U funding_before{}, value_to_sponsor{}, native_credit_after{};
};
struct Candidate {
 std::uint64_t chain_id{1}, epoch{}, current_epoch{}, block_number{};
 std::array<std::uint64_t,4> state_numbers{};
 std::uint64_t state_index{};
 std::array<std::uint64_t,4> state_indices{};
 std::array<std::array<std::uint8_t,32>,4> state_hashes{};
 std::uint64_t now_ns{}, received_ns{}, max_age_ns{}, cutoff_ns{},
               quote_expiry_ns{}, send_budget_ns{}, evidence_mask{},
               funding_known{}, package_complete{}, n{};
 U operator_initial{}, funding_cap{}, sponsor_reserve{}, overhead_reserve{},
   overhead_cost{}, sponsor_other_inflows{}, proposer_required{}, proposer_paid{},
   other_costs{}, min_sponsor_margin{}, operator_weth_new{}, min_operator_weth{};
 std::array<Step,MAX_STEPS> steps{};
};
struct Result {
 std::uint64_t reasons{};
 U total_funding{}, total_operator_gas{}, refunded{}, residual{}, sponsor_margin{};
 bool screen_pass() const { return reasons == 0; }
 // A screen NEVER authorizes a public operation.
 static constexpr bool commercial_admission = false;
};
Result screen(const Candidate& c) noexcept;
}
