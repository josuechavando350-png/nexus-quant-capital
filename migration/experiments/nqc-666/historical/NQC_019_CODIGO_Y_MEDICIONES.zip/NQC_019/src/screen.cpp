#include "screen.hpp"
namespace nqc019 {
static bool add(U a,U b,U& out) noexcept {
 if (b > MAX_U-a) return false;
 out=a+b; return true;
}
#if defined(__GNUC__) || defined(__clang__)
__attribute__((noinline))
#endif
Result screen(const Candidate& c) noexcept {
 Result r;
 if (!c.n || c.n>MAX_STEPS || c.funding_known>1 || c.package_complete>1 ||
     c.evidence_mask>REQUIRED_EVIDENCE || c.overhead_cost>c.overhead_reserve) {
   r.reasons=INVALID; return r;
 }
 if (c.evidence_mask != REQUIRED_EVIDENCE) r.reasons|=EVIDENCE_MISSING;
 if (!c.funding_known) r.reasons|=FUNDING_UNKNOWN;
 if (!c.package_complete) r.reasons|=PACKAGE_INCOMPLETE;
 if (c.operator_initial) r.reasons|=PERSONAL_CAPITAL;
 if (!c.epoch || c.epoch!=c.current_epoch) r.reasons|=GENERATION_CHANGED;
 bool hash_nonzero=false;
 for (auto b:c.state_hashes[0]) hash_nonzero|=b!=0;
 if (c.chain_id!=1 || !c.block_number || !hash_nonzero) r.reasons|=STATE_MISMATCH;
 for (std::size_t k=0;k<4;++k)
   if (c.state_numbers[k]!=c.block_number || c.state_indices[k]!=c.state_index || c.state_hashes[k]!=c.state_hashes[0])
     r.reasons|=STATE_MISMATCH;
 if (!c.received_ns || !c.max_age_ns || !c.cutoff_ns || !c.quote_expiry_ns ||
     c.now_ns<c.received_ns || c.now_ns-c.received_ns>c.max_age_ns ||
     !c.send_budget_ns || c.now_ns>=c.cutoff_ns || c.now_ns>=c.quote_expiry_ns ||
     c.send_budget_ns>=c.cutoff_ns-c.now_ns || c.send_budget_ns>=c.quote_expiry_ns-c.now_ns) r.reasons|=TIME_INVALID;
 U balance=c.operator_initial;
 for (std::size_t k=0;k<c.n;++k) {
   const auto& s=c.steps[k];
   if (!s.gas_limit || s.gas_used>s.gas_limit || s.effective_price>s.max_fee) {
     r.reasons|=INVALID; return r;
   }
   U reserve=U(s.gas_limit)*s.max_fee, cost=U(s.gas_used)*s.effective_price, needed{};
   if (!add(reserve,s.value_to_sponsor,needed) ||
       !add(balance,s.funding_before,balance) ||
       !add(r.total_funding,s.funding_before,r.total_funding)) {
     r.reasons|=OVERFLOW; return r;
   }
   if (balance<needed) { r.reasons|=PREFIX_INSUFFICIENT; return r; }
   balance-=cost;
   balance-=s.value_to_sponsor;
   if (!add(balance,s.native_credit_after,balance) ||
       !add(r.total_operator_gas,cost,r.total_operator_gas) ||
       !add(r.refunded,s.value_to_sponsor,r.refunded)) {
     r.reasons|=OVERFLOW; return r;
   }
 }
 r.residual=balance;
 if (r.total_funding>c.funding_cap) r.reasons|=FUNDING_CAP;
 if (balance) r.reasons|=RESIDUAL_FINANCING;
 U initial_required{},income{},expense{};
 if (!add(r.total_funding,c.overhead_reserve,initial_required) ||
     !add(initial_required,c.proposer_paid,initial_required) ||
     !add(c.sponsor_other_inflows,r.refunded,income) ||
     !add(r.total_funding,c.overhead_cost,expense) ||
     !add(expense,c.proposer_paid,expense) ||
     !add(expense,c.other_costs,expense)) {
   r.reasons|=OVERFLOW; return r;
 }
 if (initial_required>c.sponsor_reserve) r.reasons|=SPONSOR_RESERVE;
 if (c.proposer_paid<c.proposer_required) r.reasons|=PROPOSER_UNPAID;
 if (income<=expense) r.reasons|=SPONSOR_MARGIN;
 else {r.sponsor_margin=income-expense;
   if(r.sponsor_margin<c.min_sponsor_margin) r.reasons|=SPONSOR_MARGIN;}
 if (!c.operator_weth_new || c.operator_weth_new<c.min_operator_weth)
   r.reasons|=OPERATOR_MARGIN;
 return r;
}
}
