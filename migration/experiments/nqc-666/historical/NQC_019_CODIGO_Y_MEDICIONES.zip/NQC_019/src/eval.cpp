#include "io.hpp"
#include <iostream>
#include <sstream>
int main(){std::string line;while(std::getline(std::cin,line)){try{std::istringstream in(line);
 nqc019::emit(std::cout,nqc019::screen(nqc019::read(in)));}
 catch(const std::exception&){std::cout<<"PARSE_ERROR\n";}}}
