#include "io.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <ctime>
#include <sched.h>
#include <immintrin.h>
#include <cstring>
using namespace nqc019;
static std::uint64_t tick(){
 timespec ts{};
 if(clock_gettime(CLOCK_MONOTONIC_RAW,&ts)!=0) { throw std::runtime_error("clock_gettime failed"); }
 return std::uint64_t(ts.tv_sec)*1000000000ULL+ts.tv_nsec;
}
static void flush_input(const Candidate& c){
 auto first=reinterpret_cast<std::uintptr_t>(&c)&~std::uintptr_t(63);
 auto end=reinterpret_cast<std::uintptr_t>(&c)+sizeof(c);
 for(auto p=first;p<end;p+=64)_mm_clflush(reinterpret_cast<const void*>(p));
 _mm_mfence();
}
static void save(const std::string& path,const std::vector<std::uint64_t>& ns){
 std::ofstream f(path,std::ios::binary);if(!f)throw std::runtime_error("output open");
 f.write(reinterpret_cast<const char*>(ns.data()),std::streamsize(ns.size()*sizeof(ns[0])));
 if(!f)throw std::runtime_error("output write");
}
int main(int argc,char** argv){try{
 if(argc!=6)throw std::invalid_argument("bench CORPUS COUNT SEED FLUSH(0/1) OUT_PREFIX");
 const auto count=std::stoull(argv[2]);std::uint64_t rng=std::stoull(argv[3]);
 const bool cold=std::string(argv[4])=="1";const std::string prefix=argv[5];
 if(count<100 || count>1000000)throw std::invalid_argument("sample count");
 cpu_set_t allowed;CPU_ZERO(&allowed);if(sched_getaffinity(0,sizeof(allowed),&allowed))throw std::runtime_error("affinity read");
 int cpu=-1;for(int i=0;i<CPU_SETSIZE;++i)if(CPU_ISSET(i,&allowed)){cpu=i;break;}
 if(cpu<0) { throw std::runtime_error("no permitted CPU"); }
 cpu_set_t one;CPU_ZERO(&one);CPU_SET(cpu,&one);
 if(sched_setaffinity(0,sizeof(one),&one))throw std::runtime_error("affinity pin");
 std::ifstream input(argv[1]);if(!input)throw std::runtime_error("corpus open");
 std::vector<Candidate> data;std::string line;while(std::getline(input,line)){std::istringstream in(line);data.push_back(read(in));}
 if(data.empty())throw std::invalid_argument("empty corpus");
 std::uint64_t checksum=0,passes=0;std::vector<std::uint64_t> samples; samples.reserve(count);
 // Warm code and entries first. Cold-input trials explicitly flush data afterwards.
 for(unsigned i=0;i<10000;++i){const auto r=screen(data[i%data.size()]);checksum+=std::uint64_t(r.refunded)^r.reasons;}
 std::vector<std::uint64_t> overhead;overhead.reserve(10000);
 for(unsigned i=0;i<10000;++i){const auto t=tick();const auto t2=tick();overhead.push_back(t2-t);}
 for(std::uint64_t i=0;i<count;++i){
  rng^=rng<<13;rng^=rng>>7;rng^=rng<<17;
  const auto& c=data[rng%data.size()];if(cold)flush_input(c);
  asm volatile("" : : "g"(&c) : "memory");
  const auto start=tick();const auto r=screen(c);const auto end=tick();
  asm volatile("" : : "g"(&r) : "memory");
  samples.push_back(end-start);passes+=r.screen_pass();
  checksum+=std::uint64_t(r.sponsor_margin)^std::uint64_t(r.refunded)^r.reasons;
 }
 save(prefix+".bin",samples);save(prefix+"_clock.bin",overhead);
 timespec res{};clock_getres(CLOCK_MONOTONIC_RAW,&res);
 std::cout<<"{\"samples\":"<<count<<",\"passes\":"<<passes<<",\"checksum\":"<<checksum
 <<",\"input_records\":"<<data.size()<<",\"candidate_bytes\":"<<sizeof(Candidate)
 <<",\"cpu_affinity\":"<<cpu<<",\"clock_resolution_ns\":"<<(res.tv_sec*1000000000ULL+res.tv_nsec)
 <<",\"input_flush_requested\":"<<(cold?"true":"false")<<",\"commercial_admission\":false}\n";
 return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
