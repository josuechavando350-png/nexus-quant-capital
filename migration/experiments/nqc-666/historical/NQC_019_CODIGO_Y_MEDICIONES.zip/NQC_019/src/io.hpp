#pragma once
#include "screen.hpp"
#include <algorithm>
#include <istream>
#include <ostream>
#include <stdexcept>
#include <string>
#include <limits>
namespace nqc019 {
inline U u128(const std::string& s) {
 if (s.empty() || s.size()>39) throw std::invalid_argument("uint128 length");
 U x=0;
 for(char c:s) { if(c<'0'||c>'9')throw std::invalid_argument("uint128 digit");
   auto d=unsigned(c-'0'); if(x>(MAX_U-d)/10)throw std::invalid_argument("uint128 overflow"); x=x*10+d; }
 return x;
}
inline std::string str(U x) { if(!x)return "0";std::string s;
 while(x){s.push_back(char('0'+x%10));x/=10;}std::reverse(s.begin(),s.end());return s;}
inline U money(std::istream& in){std::string s;if(!(in>>s))throw std::invalid_argument("missing field");return u128(s);}
inline std::uint64_t word(std::istream& in){
 U x=money(in);
 if(x>std::numeric_limits<std::uint64_t>::max()) {
  throw std::invalid_argument("uint64 overflow");
 }
 return std::uint64_t(x);
}
inline Candidate read(std::istream& in) {
 Candidate c;
 auto rd=[&](auto& x){x=word(in);};
 rd(c.chain_id);rd(c.epoch);rd(c.current_epoch);rd(c.block_number);
 for(auto& n:c.state_numbers)rd(n);
 rd(c.state_index);for(auto& n:c.state_indices)rd(n);
 for(auto& h:c.state_hashes){std::string s;if(!(in>>s)||s.size()!=64)throw std::invalid_argument("hash length");
   for(unsigned i=0;i<32;++i){auto nib=[](char b)->unsigned {if(b>='0'&&b<='9')return b-'0';
     if(b>='a'&&b<='f') { return b-'a'+10; }
     throw std::invalid_argument("hash digit");};
     h[i]=std::uint8_t(nib(s[2*i])*16+nib(s[2*i+1]));}}
 rd(c.now_ns);rd(c.received_ns);rd(c.max_age_ns);rd(c.cutoff_ns);rd(c.quote_expiry_ns);
 rd(c.send_budget_ns);rd(c.evidence_mask);rd(c.funding_known);rd(c.package_complete);rd(c.n);
 if(c.n>MAX_STEPS)throw std::invalid_argument("too many steps");
 U* amounts[]={&c.operator_initial,&c.funding_cap,&c.sponsor_reserve,&c.overhead_reserve,
  &c.overhead_cost,&c.sponsor_other_inflows,&c.proposer_required,&c.proposer_paid,&c.other_costs,
  &c.min_sponsor_margin,&c.operator_weth_new,&c.min_operator_weth};
 for(auto x:amounts)*x=money(in);
 for(std::size_t i=0;i<c.n;++i){auto& s=c.steps[i];rd(s.gas_limit);rd(s.max_fee);rd(s.gas_used);rd(s.effective_price);
   s.funding_before=money(in);s.value_to_sponsor=money(in);s.native_credit_after=money(in);}
 std::string tail;if(in>>tail)throw std::invalid_argument("extra field");return c;
}
inline void emit(std::ostream& out,const Result& r){out<<r.reasons<<' '<<str(r.total_funding)<<' '
 <<str(r.total_operator_gas)<<' '<<str(r.refunded)<<' '<<str(r.residual)<<' '<<str(r.sponsor_margin)<<'\n';}
}
