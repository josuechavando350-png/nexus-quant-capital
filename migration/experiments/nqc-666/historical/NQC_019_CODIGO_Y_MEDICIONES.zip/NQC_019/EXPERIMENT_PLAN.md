# NQC019 - preregistered offline screening experiment

Written before benchmarks. Continue NQC018; no public transactions, signatures,
provider contacts, spending or edits to existing source. This is a NEW ISOLATED
C++ pre-screen, not an optimization of a recovered 11 us baseline. The 11 us
artifact is NOT LOCATED in the scoped Library evidence, not disproved.

Question: can a bounded exact-integer funding/evidence pre-screen run below
3,000 ns at p99 in this sandbox without omitting native reserve, refund, sponsor,
proposer, consistent-state and temporal checks?

Data boundary: already parsed, typed, externally verified/pre-simulated records
in memory, 1..16 operator transactions. No RPC, pricing, discovery, simulation,
cryptographic proof validation, signature, serialization, network submission or
inclusion is timed. Declared evidence flags are assertions of a future upstream
adapter; this experiment does NOT implement or verify that adapter. Every result
has commercial_admission=false. A passed screen is not permission to trade.

Amounts: checked unsigned 128-bit integer wei / token base units; inputs outside
that explicit domain are rejected, not truncated from Ethereum uint256. ETH and
WETH are kept distinct. Gas limit * max fee is the upfront reserve; actual gas
cost is separate. A conservative sponsor reserve includes all advances, overhead
reserve and proposer payout before operation proceeds; it is sufficient, not a
claim of the minimal possible financing. All money inflows require upstream
verification. Unknown terms or funding remain blocked.

Correctness: explicit negative/boundary cases, independent Python big-integer
prefix-sum oracle against incremental C++, seed-fixed random differential corpus,
NQC018 summary projection (NOT a 68-receipt reconstruction), parser rejection,
and sanitizer build. Run existing NQC018 code unchanged only as a scoped oracle
for its summary gate, not its EVM suite. Never count arithmetic cases as trades.

Performance: compile separately without LTO; observable checksum; preconstructed
but runtime-varied records; no allocations or I/O inside screen. Five repetitions
of 200,000 individual timings per warm 4-step, warm 16-step and mixed 16-step
workload; five of 20,000 after explicit input cache-line flushes on x86. Save all
uint64 nanosecond samples and report p50/p95/p99/max and count >3000 ns. Nearest
rank percentiles, no overhead subtraction and no outlier removal. Empty clock
control is measured separately. Pin only the current process to a permitted CPU;
no privileged tuning. Compiler, flags, CPU, clock and source hashes are recorded.
All five warm p99 must be <=3000 ns for that specific workload target. Cold input
and maximum latency reported even if worse. This is not a deterministic maximum
latency guarantee. No comparison speedup to 11 us without its original artifact.

Commercial priority remains a provider-applicable precommit funding declaration
or bounded settlement, complete authentic prestate and observed competitive
cutoff. Faster screening does not fill those inputs.
