# NQC666 R2 — registro previo de la hipótesis

Base inmutable: fef142e0310c72ebc1f634e5b5c3f445fe6c4b4e. R1 y NQC666 no se editan.
Hipótesis: vencimientos simultáneos cuestan O(K log 256) en el selector anterior.
Tras 16 líderes inválidos, dos barridos y reconstrucción O(256) pueden reducir ese
coste. No se asume que ganen con uno o pocos vencimientos. Se fija 16 antes de medir.

Semántica: mismo candidato, desempate menor slot, misma invalidación de generaciones,
mismo estado de prioridad observable incluso si el tiempo retrocede. Sólo quitar
los inválidos que el selector anterior habría visitado antes del primer válido.
Defensa financiera final reutilizada directamente desde nqc666::engine::guard.
No saltar comprobaciones financieras, matemáticas, temporales o de financiación.

Medir el original y la variante con igual compilación O3/fat LTO/overflow checks,
afinidad permitida de un CPU, orden intercalado reproducible, CLOCK_MONOTONIC_RAW,
control vacío, muestras individuales sin restar overhead ni descartar máximos.
Entradas sintéticas: 256 slots, ráfagas de 0,1,8,16,64,128,255 líderes vencidos;
rotación del superviviente y valores/tiempos variables. Registrar p50/p95/p99/p99.9/max.
Comparar selección + defensa final (precarga fuera del reloj), ciclo completo de
256 actualizaciones + selección/defensa (precarga dentro), y el recorrido R1 ordinario
con matemática/adaptador/evento/selección/defensa. Registrar alcance de cada ventana.
No confundir estas ventanas con red/builder/EVM/inclusión ni con 5 ns.

La selección muta estado: exponer el resultado completo y el motor a black_box dentro
de la ventana, consumir salida después, comparar checksums y pruebas de continuación.
Aceptar únicamente si preserva equivalencia, mejora el caso de ráfaga y documenta
regresiones normales y de cola. No elegir por un máximo aislado en una VM no controlada.
Si no mejora justificadamente, conservarlo como experimento rechazado sin promoción.
