//! Offline NQC666 research. No signing, submission or commercial authorization API.
pub mod financial;
pub mod prepared;
pub mod third_eye;
pub mod engine;
#[doc(hidden)]
pub mod fixtures;
