// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
interface IAaveOracleBlockBatch {
    function getAssetPrice(address asset) external view returns (uint256);
}
contract NqcAaveOraclePriceBlockBatch {
    address constant ORACLE = 0x54586bE62E3c3580375aE3723C145253060Ca0C2;
    constructor(bytes memory packedAssets) {
        require(packedAssets.length > 0 && packedAssets.length % 20 == 0, "shape");
        uint256 n=packedAssets.length/20;
        require(n<=128,"n");
        bytes32[] memory out=new bytes32[](n+4);
        out[0]=bytes32(block.number);
        out[1]=bytes32(block.timestamp);
        out[2]=bytes32(block.basefee);
        out[3]=blockhash(block.number-1);
        for(uint256 i=0;i<n;++i){
            address asset;
            assembly ("memory-safe") {
                asset := shr(96,mload(add(add(packedAssets,32),mul(i,20))))
            }
            out[i+4]=bytes32(IAaveOracleBlockBatch(ORACLE).getAssetPrice(asset));
        }
        bytes memory encoded=abi.encode(out);
        assembly ("memory-safe"){return(add(encoded,32),mload(encoded))}
    }
}
