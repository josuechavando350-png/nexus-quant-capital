// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {NqcFlashFundingExecutor, IERC20FlashMinimal} from "../src/NqcFlashFundingExecutor.sol";


interface IBalancerFeeModuleScenario {
    function getFlashLoanFeePercentage() external view returns (uint256);
}
interface IBalancerVaultFeeScenario {
    function getProtocolFeesCollector() external view returns (address);
}

interface IWethSettlementScenario {
    function withdraw(uint256 amount) external;
}

interface VmRmc016 {
    function envAddress(string calldata name) external returns (address);
    function envUint(string calldata name) external returns (uint256);
    function roll(uint256 value) external;
    function warp(uint256 value) external;
}

interface IAavePoolRmc016 {
    function getUserAccountData(address borrower)
        external view returns (
            uint256 collateralBase, uint256 debtBase, uint256 availableBorrowBase,
            uint256 liquidationThreshold, uint256 ltv, uint256 healthFactor
        );
    function liquidationCall(
        address collateralAsset, address debtAsset, address borrower,
        uint256 debtToCover, bool receiveAToken
    ) external;
    function FLASHLOAN_PREMIUM_TOTAL() external view returns (uint128);
}

contract NqcRmc016WethActualLiquidationStrategy {
    address internal constant HISTORICAL_FEE_RECIPIENT = 0x6Adb3baB5730852eB53987EA89D8e8f16393C200;
    uint256 internal constant HISTORICAL_PAYMENT = 95915734379292898;
    address public immutable weth;
    address public immutable pool;
    address public immutable borrower;
    address public immutable operator;
    address public executor;

    constructor(address weth_, address pool_, address borrower_) {
        weth = weth_;
        pool = pool_;
        borrower = borrower_;
        operator = msg.sender;
    }

    receive() external payable {
        require(msg.sender == weth, "ONLY_WETH_NATIVE_RECEIPT");
    }

    function setExecutor(address executor_) external {
        require(msg.sender == operator && executor == address(0), "TEST_EXECUTOR_SETUP_ONLY");
        executor = executor_;
    }

    function executeFunded(bytes32, address asset, uint256 principal, bytes calldata)
        external returns (uint256 returnedAssetUnits)
    {
        require(msg.sender == executor && asset == weth, "UNAUTHORIZED_STRATEGY_CALLBACK");
        // No vm.deal, ERC20 deal, preloaded strategy inventory or fee sponsor.
        require(IERC20FlashMinimal(weth).balanceOf(address(this)) == principal,
                "NON_FRESH_STRATEGY_PRINCIPAL");
        require(IERC20FlashMinimal(weth).approve(pool, principal), "APPROVE_REAL_AAVE");
        IAavePoolRmc016(pool).liquidationCall(weth, weth, borrower, principal, false);
        require(IERC20FlashMinimal(weth).approve(pool, 0), "CLEAR_REAL_AAVE_APPROVAL");

        uint256 nativeBefore = address(this).balance;
        IWethSettlementScenario(weth).withdraw(HISTORICAL_PAYMENT);
        require(address(this).balance == nativeBefore + HISTORICAL_PAYMENT, "UNWRAP_DELTA_MISMATCH");
        (bool paid,) = payable(HISTORICAL_FEE_RECIPIENT).call{value: HISTORICAL_PAYMENT}("");
        require(paid && address(this).balance == nativeBefore, "HISTORICAL_PAYMENT_NOT_SETTLED");
        returnedAssetUnits = IERC20FlashMinimal(weth).balanceOf(address(this));
        require(returnedAssetUnits > principal, "NO_LIQUIDATION_BONUS_IN_WETH");
        require(IERC20FlashMinimal(weth).transfer(msg.sender, returnedAssetUnits),
                "RETURN_SEIZED_WETH_TO_FLASH_EXECUTOR");
    }
}

/// @notice NEW RESEARCH FUNDING SCENARIO derived from the historical test;
/// not original evidence. WETH/WETH liquidation attempt from
/// the predecessor fork moved ONLY to the winner block's timestamp.
/// @dev Retrospective competitor selection, no in-block tx replay. No native
/// gas sponsor, capital admission, execution inclusion or live Nexus P&L.
contract NqcFundingComparisonForkTest {
    VmRmc016 internal constant vm =
        VmRmc016(address(uint160(uint256(keccak256("hevm cheat code")))));

    address internal constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    address internal constant POOL = 0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2;
    address internal constant BALANCER = 0xBA12222222228d8Ba445958a75a0704d566BF2C8;
    address internal constant HISTORICAL_FEE_RECIPIENT = 0x6Adb3baB5730852eB53987EA89D8e8f16393C200;
    uint256 internal constant HISTORICAL_PAYMENT = 95915734379292898;
    uint256 internal constant PREVIOUS_BLOCK = 25_938_047;
    uint256 internal constant WINNER_BLOCK = 25_938_048;
    uint256 internal constant REPAY_PRINCIPAL = 10_684_013_854_557_827_871;
    uint256 internal constant PREVIOUS_HF_WAD = 1_000_000_001_993_818_630;
    uint256 internal constant TIME_ONLY_HF_WAD = 999_999_999_704_293_538;

    NqcFlashFundingExecutor internal flashExecutor;
    NqcRmc016WethActualLiquidationStrategy internal strategy;
    address internal borrower;
    uint256 internal winnerTime;

    event log_named_uint(string label, uint256 value);

    function setUp() public {
        require(block.chainid == 1 && block.number == PREVIOUS_BLOCK,
                "NOT_CANONICAL_PREDECESSOR_FORK");
        borrower = vm.envAddress("NQC_RMC016_RANK1_BORROWER");
        winnerTime = vm.envUint("NQC_RMC016_RANK1_WINNER_TIMESTAMP");
        uint256 previousTime = vm.envUint("NQC_RMC016_RANK1_PREVIOUS_TIMESTAMP");
        require(block.timestamp == previousTime && winnerTime > previousTime,
                "CANONICAL_HISTORICAL_TIMESTAMPS_NOT_PINNED");

        strategy = new NqcRmc016WethActualLiquidationStrategy(WETH, POOL, borrower);
        flashExecutor = new NqcFlashFundingExecutor(address(this), address(strategy));
        strategy.setExecutor(address(flashExecutor));

        require(IERC20FlashMinimal(WETH).balanceOf(address(strategy)) == 0,
                "STRATEGY_OWNS_PREEXISTING_WETH");
        require(IERC20FlashMinimal(WETH).balanceOf(address(flashExecutor)) == 0,
                "FLASH_EXECUTOR_OWNS_PREEXISTING_WETH");
    }

    function _hf() internal view returns (uint256 hf) {
        (,,,,,hf) = IAavePoolRmc016(POOL).getUserAccountData(borrower);
    }

    function _advanceClockOnly() internal {
        require(_hf() == PREVIOUS_HF_WAD, "SOURCE_PREVIOUS_HF_MISMATCH");
        vm.roll(WINNER_BLOCK);
        vm.warp(winnerTime);
        require(_hf() == TIME_ONLY_HF_WAD, "SOURCE_TIME_ONLY_HF_MISMATCH");
        require(_hf() < 1 ether, "BORROWER_NOT_ELIGIBLE_AT_SIMULATED_WINNER_TIME");
    }

    function _fee(uint256 principal) internal view returns (uint256) {
        address collector = IBalancerVaultFeeScenario(BALANCER).getProtocolFeesCollector();
        uint256 rate = IBalancerFeeModuleScenario(collector).getFlashLoanFeePercentage();
        require(rate <= 1 ether, "INVALID_FLASH_FEE_RATE");
        uint256 product = principal * rate;
        return product == 0 ? 0 : (product - 1) / 1 ether + 1;
    }

    function _plan(bytes memory payload, uint256 fee, uint256 minProfit)
        internal pure returns (NqcFlashFundingExecutor.FlashExecutionPlan memory p)
    {
        NqcFlashFundingExecutor.FundingLeg[] memory legs =
            new NqcFlashFundingExecutor.FundingLeg[](1);
        legs[0] = NqcFlashFundingExecutor.FundingLeg({
            sourceKind:2,
            lender:BALANCER,
            principal:REPAY_PRINCIPAL,
            expectedFee:fee,
            callbackSemanticsHash:keccak256("T36_BALANCER_V2_CALLBACK_SCENARIO"),
            // This nonzero hash is a test fixture only, NOT a capital quote.
            sourceEvidenceHash:keccak256("RMC016_FORK_ONLY_UNFUNDED_GAS_NO_AUTHORIZED_PROVIDER")
        });
        p = NqcFlashFundingExecutor.FlashExecutionPlan({
            chainId:1,
            validThroughBlock:WINNER_BLOCK,
            executionIdentityHash:keccak256(abi.encodePacked("RMC016_RANK1_TIME_ONLY",payload)),
            fundingPlanHash:keccak256(abi.encodePacked("RMC016_RANK1_FLASH_FIXTURE",payload)),
            anchorHash:keccak256(abi.encodePacked("RMC016_RANK1_PREBLOCK",payload)),
            canonicalGeneration:1,
            asset:WETH,
            principalRequired:REPAY_PRINCIPAL,
            minProfitAsset:minProfit,
            payloadHash:keccak256(payload),
            legs:legs
        });
    }

    function testZeroOwnWethFeeWithoutExternalSponsorHasPositiveForkSurplus() public {
        _advanceClockOnly();
        bytes memory payload = hex"163701";
        uint256 flashFee = _fee(REPAY_PRINCIPAL);
        uint256 vaultLiquidity = IERC20FlashMinimal(WETH).balanceOf(BALANCER);
        require(vaultLiquidity >= REPAY_PRINCIPAL, "INSUFFICIENT_REAL_VAULT_LIQUIDITY");
        emit log_named_uint("NQC_RANK1_FORK_VAULT_LIQUIDITY_WEI", vaultLiquidity);
        address collector = IBalancerVaultFeeScenario(BALANCER).getProtocolFeesCollector();
        emit log_named_uint("NQC_RANK1_FORK_VAULT_FEE_WAD", IBalancerFeeModuleScenario(collector).getFlashLoanFeePercentage());
        require(HISTORICAL_FEE_RECIPIENT.code.length == 0, "RECIPIENT_BEHAVIOR_NOT_EOA");
        uint256 recipientBefore = HISTORICAL_FEE_RECIPIENT.balance;
        uint256 strategyNativeBefore = address(strategy).balance;
        uint256 operatorWethBefore = IERC20FlashMinimal(WETH).balanceOf(address(this));
        // Build the plan before measuring so the counted portion is only the
        // actual cross-contract coordinator call, including Aave flash borrow,
        // liquidation, repayment, callbacks and profit sweep.
        NqcFlashFundingExecutor.FlashExecutionPlan memory actualPlan =
            _plan(payload, flashFee, 1);
        bytes memory encoded = abi.encodeWithSelector(flashExecutor.execute.selector, actualPlan, payload);
        uint256 zeroBytes;
        for (uint256 i; i < encoded.length; ++i) {
            if (encoded[i] == 0) ++zeroBytes;
        }
        uint256 gasBefore = gasleft();
        uint256 output = flashExecutor.execute(actualPlan, payload);
        uint256 measuredExecutionGas = gasBefore - gasleft();
        require(measuredExecutionGas > 100_000 && measuredExecutionGas < 3_000_000,
                "FORK_GAS_CALL_MEASUREMENT_IMPLAUSIBLE");

        require(output > 0, "NO_WETH_SURPLUS_AFTER_FLASH_FEE");
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) ==
                operatorWethBefore + output, "FRESH_PROFIT_NOT_SWEPT_TO_OPERATOR");
        require(IERC20FlashMinimal(WETH).balanceOf(address(flashExecutor)) == 0,
                "EXECUTOR_POST_REPAYMENT_WETH_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(address(strategy)) == 0,
                "STRATEGY_POST_REPAYMENT_WETH_DRIFT");
        require(HISTORICAL_FEE_RECIPIENT.balance == recipientBefore + HISTORICAL_PAYMENT,
                "NATIVE_RECIPIENT_DELTA_MISMATCH");
        require(address(strategy).balance == strategyNativeBefore, "STRATEGY_NATIVE_BALANCE_DRIFT");
        emit log_named_uint("NQC_RANK1_FORK_NATIVE_BASELINE_WEI", strategyNativeBefore);
        emit log_named_uint("NQC_RANK1_FORK_SETTLED_NATIVE_PAYMENT_WEI", HISTORICAL_PAYMENT);
        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_BYTES", encoded.length);
        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_ZERO_BYTES", zeroBytes);
        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_NONZERO_BYTES", encoded.length - zeroBytes);
        emit log_named_uint("NQC_RANK1_FORK_INTRINSIC_GAS_4_16", 21000 + zeroBytes * 4 + (encoded.length - zeroBytes) * 16);
        emit log_named_uint("NQC_RANK1_FORK_EXECUTE_CALL_GAS_UNITS", measuredExecutionGas);
        // The call gas excludes transaction intrinsic/calldata, trigger
        // detection, revert attempts, builder and sponsor overhead.
        emit log_named_uint("NQC_RANK1_FORK_WETH_SURPLUS_WEI", output);
        emit log_named_uint("NQC_RANK1_FORK_FLASH_FEE_WEI", flashFee);
        emit log_named_uint("NQC_RANK1_FORK_PRODUCTION_GAS_SPONSORED", 0);
    }

    function testImpossibleProfitClaimRevertsAndCannotSpendExistingBalances() public {
        _advanceClockOnly();
        bytes memory payload = hex"163702";
        uint256 fee = _fee(REPAY_PRINCIPAL);
        uint256 operatorBefore = IERC20FlashMinimal(WETH).balanceOf(address(this));
        uint256 debtorHfBefore = _hf();
        uint256 recipientBefore = HISTORICAL_FEE_RECIPIENT.balance;
        uint256 strategyNativeBefore = address(strategy).balance;
        uint256 lenderBefore = IERC20FlashMinimal(WETH).balanceOf(BALANCER);

        NqcFlashFundingExecutor.FlashExecutionPlan memory p =
            _plan(payload, fee, type(uint96).max);
        (bool ok,) = address(flashExecutor).call(
            abi.encodeWithSelector(flashExecutor.execute.selector,p,payload)
        );
        require(!ok, "UNSUPPORTED_PROFIT_WAS_ACCEPTED");
        require(HISTORICAL_FEE_RECIPIENT.balance == recipientBefore, "REVERT_DID_NOT_ROLL_BACK_NATIVE_PAYMENT");
        require(IERC20FlashMinimal(WETH).balanceOf(BALANCER) == lenderBefore, "REVERT_DID_NOT_ROLL_BACK_LENDER_BALANCE");
        require(address(strategy).balance == strategyNativeBefore, "FAILED_OPERATION_NATIVE_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) == operatorBefore,
                "FAILED_OPERATION_CREDITED_WETH");
        require(IERC20FlashMinimal(WETH).balanceOf(address(strategy)) == 0,
                "FAILED_OPERATION_STRATEGY_WETH_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(address(flashExecutor)) == 0,
                "FAILED_OPERATION_EXECUTOR_WETH_DRIFT");
        require(_hf() == debtorHfBefore, "FAILED_LIQUIDATION_MUTATED_BORROWER");
        require(!flashExecutor.consumedExecutionIdentity(p.executionIdentityHash),
                "FAILED_OPERATION_CONSUMED_IDENTITY");
    }
}


/// Research operator harness only; no production authorization or gas funding.
contract NqcNativeRealizationForkTest is NqcFundingComparisonForkTest {
    receive() external payable {
        require(msg.sender == WETH, "NATIVE_REALIZATION_ONLY_WETH");
    }

    function settleToNative(NqcFlashFundingExecutor.FlashExecutionPlan calldata p, bytes calldata payload)
        external returns (uint256 output)
    {
        require(msg.sender == address(this), "HARNESS_SELF_CALL_ONLY");
        uint256 wethBefore = IERC20FlashMinimal(WETH).balanceOf(address(this));
        uint256 nativeBefore = address(this).balance;
        output = flashExecutor.execute(p, payload);
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) == wethBefore + output,
                "FRESH_OUTPUT_NOT_RECEIVED");
        IWethSettlementScenario(WETH).withdraw(output);
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) == wethBefore,
                "EXISTING_OPERATOR_WETH_SPENT");
        require(address(this).balance == nativeBefore + output, "NATIVE_REALIZATION_DELTA");
    }

    function testAtomicNativeRealizationPreservesPriorInventory() public {
        _advanceClockOnly();
        bytes memory payload = hex"163703";
        NqcFlashFundingExecutor.FlashExecutionPlan memory p = _plan(payload, _fee(REPAY_PRINCIPAL), 1);
        uint256 wethBefore = IERC20FlashMinimal(WETH).balanceOf(address(this));
        uint256 nativeBefore = address(this).balance;
        uint256 recipientBefore = HISTORICAL_FEE_RECIPIENT.balance;
        bytes memory encoded = abi.encodeWithSelector(this.settleToNative.selector, p, payload);
        uint256 zeroBytes;
        for (uint256 i; i < encoded.length; ++i) if (encoded[i] == 0) ++zeroBytes;
        uint256 gasBefore = gasleft();
        uint256 output = this.settleToNative(p, payload);
        uint256 measured = gasBefore - gasleft();
        require(output == 240390311727552, "NATIVE_OUTPUT_DIFFERS_FROM_PAIRED_FORK");
        require(address(this).balance == nativeBefore + output, "OPERATOR_NATIVE_NOT_CREDITED");
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) == wethBefore, "PRIOR_WETH_DRIFT");
        require(HISTORICAL_FEE_RECIPIENT.balance == recipientBefore + HISTORICAL_PAYMENT, "ATOMIC_BID_NOT_PAID");
        require(IERC20FlashMinimal(WETH).balanceOf(address(strategy)) == 0, "STRATEGY_REMAINDER");
        require(IERC20FlashMinimal(WETH).balanceOf(address(flashExecutor)) == 0, "EXECUTOR_REMAINDER");
        emit log_named_uint("NQC_NATIVE_REALIZED_WEI", output);
        emit log_named_uint("NQC_NATIVE_SETTLEMENT_CALL_GAS", measured);
        emit log_named_uint("NQC_NATIVE_CALLDATA_BYTES", encoded.length);
        emit log_named_uint("NQC_NATIVE_ZERO_BYTES", zeroBytes);
        emit log_named_uint("NQC_NATIVE_NONZERO_BYTES", encoded.length - zeroBytes);
        emit log_named_uint("NQC_NATIVE_INTRINSIC_4_16", 21000 + 4 * zeroBytes + 16 * (encoded.length - zeroBytes));
    }

    function testNativeRealizationRevertPreservesAllBalances() public {
        _advanceClockOnly();
        bytes memory payload = hex"163704";
        NqcFlashFundingExecutor.FlashExecutionPlan memory p = _plan(payload, _fee(REPAY_PRINCIPAL), type(uint96).max);
        uint256 wethBefore = IERC20FlashMinimal(WETH).balanceOf(address(this));
        uint256 nativeBefore = address(this).balance;
        uint256 recipientBefore = HISTORICAL_FEE_RECIPIENT.balance;
        uint256 strategyNativeBefore = address(strategy).balance;
        uint256 lenderBefore = IERC20FlashMinimal(WETH).balanceOf(BALANCER);
        uint256 hfBefore = _hf();
        (bool ok,) = address(this).call(abi.encodeWithSelector(this.settleToNative.selector, p, payload));
        require(!ok, "IMPOSSIBLE_NATIVE_OUTPUT_ACCEPTED");
        require(address(this).balance == nativeBefore, "REVERT_NATIVE_INVENTORY_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(address(this)) == wethBefore, "REVERT_WETH_INVENTORY_DRIFT");
        require(HISTORICAL_FEE_RECIPIENT.balance == recipientBefore, "REVERT_BID_NOT_ROLLED_BACK");
        require(address(strategy).balance == strategyNativeBefore, "REVERT_STRATEGY_NATIVE_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(BALANCER) == lenderBefore, "REVERT_LENDER_DRIFT");
        require(IERC20FlashMinimal(WETH).balanceOf(address(strategy)) == 0, "REVERT_STRATEGY_REMAINDER");
        require(IERC20FlashMinimal(WETH).balanceOf(address(flashExecutor)) == 0, "REVERT_EXECUTOR_REMAINDER");
        require(_hf() == hfBefore, "REVERT_BORROWER_DRIFT");
        require(!flashExecutor.consumedExecutionIdentity(p.executionIdentityHash), "REVERT_IDENTITY_CONSUMED");
    }
}
