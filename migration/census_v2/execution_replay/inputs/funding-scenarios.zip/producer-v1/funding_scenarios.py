"""Pinned research overlays; immutable historical inputs are never edited."""
from pathlib import Path
from rpc_witness import sha
from run_fork import TEST_PATH, PATCHED_TEST_SHA

VAULT = "0xBA12222222228d8Ba445958a75a0704d566BF2C8"
SCENARIO_SHAS = {
    "aave": "0aca5fe9ff8f05c1fad52691bdc0312a147498e34a257526b4c8282ffcae11bb",
    "balancer": "f8c665b28f6090660d65d95e601adc1b8baa0e96b597f3c0738fabc471e4d321",
}
FEE_INTERFACE = '''
interface IBalancerFeeModuleScenario {
    function getFlashLoanFeePercentage() external view returns (uint256);
}
interface IBalancerVaultFeeScenario {
    function getProtocolFeesCollector() external view returns (address);
}
'''
BALANCER_FEE = '''    function _fee(uint256 principal) internal view returns (uint256) {
        address collector = IBalancerVaultFeeScenario(BALANCER).getProtocolFeesCollector();
        uint256 rate = IBalancerFeeModuleScenario(collector).getFlashLoanFeePercentage();
        require(rate <= 1 ether, "INVALID_FLASH_FEE_RATE");
        uint256 product = principal * rate;
        return product == 0 ? 0 : (product - 1) / 1 ether + 1;
    }
'''
AAVE_FEE = '''    function _fee(uint256 principal) internal view returns (uint256) {
        uint256 premiumBps = uint256(IAavePoolRmc016(POOL).FLASHLOAN_PREMIUM_TOTAL());
        require(premiumBps == 5, "HISTORICAL_FEE_BPS_CHANGED");
        return (principal * premiumBps + 5000) / 10000;
    }
'''


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError("scenario preimage pattern differs")
    return text.replace(before, after)


def scenario_bytes(raw, variant):
    if sha(raw) != PATCHED_TEST_SHA or variant not in {"aave", "balancer"}:
        raise ValueError("scenario preimage or variant differs")
    text = raw.decode()
    text = replace_once(text, "contract NqcRmc016RankOneSelfFinancingForkTest {",
                        "contract NqcFundingComparisonForkTest {")
    text = replace_once(text, "/// @notice Exact source-derived historical WETH/WETH liquidation attempt from",
                        "/// @notice NEW RESEARCH FUNDING SCENARIO derived from the historical test;\n/// not original evidence. WETH/WETH liquidation attempt from")
    text = replace_once(text, "        uint256 gasBefore = gasleft();", '''        bytes memory encoded = abi.encodeWithSelector(flashExecutor.execute.selector, actualPlan, payload);
        uint256 zeroBytes;
        for (uint256 i; i < encoded.length; ++i) {
            if (encoded[i] == 0) ++zeroBytes;
        }
        uint256 gasBefore = gasleft();''')
    text = replace_once(text, '        emit log_named_uint("NQC_RANK1_FORK_EXECUTE_CALL_GAS_UNITS", measuredExecutionGas);', '''        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_BYTES", encoded.length);
        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_ZERO_BYTES", zeroBytes);
        emit log_named_uint("NQC_RANK1_FORK_CALLDATA_NONZERO_BYTES", encoded.length - zeroBytes);
        emit log_named_uint("NQC_RANK1_FORK_INTRINSIC_GAS_4_16", 21000 + zeroBytes * 4 + (encoded.length - zeroBytes) * 16);
        emit log_named_uint("NQC_RANK1_FORK_EXECUTE_CALL_GAS_UNITS", measuredExecutionGas);''')
    if variant == "balancer":
        text = replace_once(text, "interface VmRmc016 {", FEE_INTERFACE + "\ninterface VmRmc016 {")
        text = replace_once(text, "    uint256 internal constant PREVIOUS_BLOCK", "    address internal constant BALANCER = " + VAULT + ";\n    uint256 internal constant PREVIOUS_BLOCK")
        text = replace_once(text, AAVE_FEE, BALANCER_FEE)
        text = replace_once(text, "            sourceKind:1,\n            lender:POOL,", "            sourceKind:2,\n            lender:BALANCER,")
        text = replace_once(text, 'keccak256("T36_CANONICAL_REAL_AAVE_CALLBACK")', 'keccak256("T36_BALANCER_V2_CALLBACK_SCENARIO")')
        text = replace_once(text, "        uint256 flashFee = _fee(REPAY_PRINCIPAL);", '''        uint256 flashFee = _fee(REPAY_PRINCIPAL);
        uint256 vaultLiquidity = IERC20FlashMinimal(WETH).balanceOf(BALANCER);
        require(vaultLiquidity >= REPAY_PRINCIPAL, "INSUFFICIENT_REAL_VAULT_LIQUIDITY");
        emit log_named_uint("NQC_RANK1_FORK_VAULT_LIQUIDITY_WEI", vaultLiquidity);
        address collector = IBalancerVaultFeeScenario(BALANCER).getProtocolFeesCollector();
        emit log_named_uint("NQC_RANK1_FORK_VAULT_FEE_WAD", IBalancerFeeModuleScenario(collector).getFlashLoanFeePercentage());''')
    return text.encode()


def apply_scenario(source, variant, expected_sha):
    path = Path(source) / TEST_PATH
    raw = path.read_bytes()
    result = scenario_bytes(raw, variant)
    if sha(result) != expected_sha:
        raise ValueError("scenario postimage differs from published pin")
    path.write_bytes(result)
    return {"variant": variant, "path": TEST_PATH, "before_sha256": sha(raw),
            "after_sha256": sha(result), "scope": "FRESH_RESEARCH_COPY_NOT_ORIGINAL_TEST",
            "executor_modified": False, "original_non_fee_assertions_retained": True,
            "provider_fee_rule_changed": variant == "balancer"}
