#!/data/data/com.termux/files/usr/bin/python3
import hashlib,json,subprocess,sys
from pathlib import Path
raw=sys.stdin.buffer.read()
if 'lost-ack' == 'before-commit':
    if raw.count(b'\nCOMMIT;\n') != 1: raise SystemExit(9)
    raw=raw.replace(b'\nCOMMIT;\n',b'\nSELECT pg_sleep(30);\nCOMMIT;\n')
Path('/data/data/com.termux/files/home/nqc-miner-sync.OGfGFO/evidence/fault-lost-ack-input.sha256').write_text(hashlib.sha256(raw).hexdigest()+'\n')
result=subprocess.run(['/data/data/com.termux/files/usr/bin/psql',*sys.argv[1:]],input=raw,capture_output=True)
Path('/data/data/com.termux/files/home/nqc-miner-sync.OGfGFO/evidence/fault-lost-ack-underlying.json').write_text(json.dumps({'returncode':result.returncode,'stdout':result.stdout.decode(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})+'\n')
sys.stderr.buffer.write(result.stderr)
if 'lost-ack' == 'lost-ack' and result.returncode == 0:
    sys.stdout.buffer.write(result.stdout.splitlines(keepends=True)[0]);raise SystemExit(2)
sys.stdout.buffer.write(result.stdout);raise SystemExit(result.returncode)
